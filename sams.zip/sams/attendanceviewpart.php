<?php>
mysql_connect("localhost","root","");
mysql_select_db("db_sams");


 public function getDateList1(){

              $query = "SELECT DISTINCT att_time FROM tb_attendance";
              $result = $this->db->select($query);
              return $result;
          }

          public function getAllData1($db){
          	$query = "SELECT tb_student.name, tb_attendance.*
          	FROM tb_student
          	INNER JOIN tb_attendance
          	ON tb_student.roll = tb_attendance.roll 
          	WHERE attend = "present";
          	echo $result;
          /* $result = $this->db->select($query);
              return $result;*/

          }



 ?>