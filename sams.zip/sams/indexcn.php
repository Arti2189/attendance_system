<?php 
include 'inc/header.php';
include 'lib/Studentcn.php';
 ?>
 <script type="text/javascript">
 $(document).ready(function(){

  $("form").submit(function(){
    var roll = true;
    $(':radio').each(function(){
    name = $(this).attr('name');  
    if(roll && !$(':radio[name="' + name + '"]:checked').length){
   // alert(name + "Roll Missing !" );
   $('.alert').show();
    roll = false;
    }

    });
    return roll;
  });
 });
 </script>

 <?php
 error_reporting(0);
   $stu = new Student();
    $cur_date = date('Y-m-d');
   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   $attend = $_POST['attend'];
   $insertattend= $stu->insertAttendance($cur_date, $attend);
   }
   ?>
<?php
   if (isset($insertattend)) {
     echo $insertattend;
   }
   ?>
   <div class= 'alert alert-danger' style ="display:none"><strong>Error !</strong>Student Roll Missing !</div>

    


<!--<html>
<head>
<meta charset="utf-8">
<title> student attendance php</title><


<link rel= "stylesheet" href="inc/bootstrap.min.css" media="screen" title= "no title"/>
<script type="text/javascript" src="inc/jquery.min.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>
</head>-->
<body>
	<div class="container">
		<div class= "well text-center">
			<h2> Computer Networking</h2></div>

               <div class="panel panel-default"></div>
               <div class="panel-heading">
               	<h2>
               		<a class="btn btn-success" href="addcn.php">Add Student</a>
               		<a class="btn btn-info pull-right" href="date_viewcn.php">View All</a>
               	</h2>
               </div>
                <div class="panel-body">
                	<div class="well text-center" style- "font-size: 15px">
                		<strong>Date: </strong><?php $cur_date = date('y-m-d'); echo $cur_date; ?>
                       <form action="" method="post">
                       	<table class="table table-striped">
                       		<tr>
                       			<th width="25%"> Serial No.</th>
                       			<th width="25%"> Student Name</th>
                       			<th width="25%"> Enrollment No.</th>
                       			<th width="25%"> Attendance</th>
                       		</tr>


                       		<?php

                       		$get_student = $stu->getStudents();
                       		if ($get_student){
                       			$i = 0;
                       			while ($value = $get_student->fetch_assoc()) {
                       				$i++;
                       			
                       		

                       		?>
                                 <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $value['name']; ?></td>
	<td><?php echo $value['roll']; ?></td>
  
  <td>
  <input type="radio" name="attend[<?php echo $value['roll']; ?>]" value="present">P
<input type="radio" name="attend[<?php echo $value['roll']; ?>]" value="absent">A
</td>
</tr>
<?php } }  ?>


  <tr>
			<td colspan="4">
                  <input type="submit" class="btn btn-primary" name="submit" value="Submit">
			</td></tr>
                       	</table>
                   </form>
                </div>



			<div class="well">
			</div></div>

</body>
</html>