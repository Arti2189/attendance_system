 <?php
 if (isset($_POST['submit'])) {
   # code...
        error_reporting(0);
      mysql_connect("localhost","root","");
      mysql_select_db("phpclass"); 
      //$data= mysql_query($sql) or die (mysql_error());

      //$pic=$_FILES["profile_pic"]["name"];
      //$pic=$_FILES["profile_pic"]["size"];
      //$pic=$_FILES["profile_pic"]["type"];
      //$pic=$_FILES["profile_pic"]["tmp_name"];

      //move_uploaded_file($_FILES["profile_pic"]["tmp_name"],"photo/$pic");


      $fname=$_POST["fname"];
      $sname=$_POST["sname"];
      $username=$_POST["username"];
      $email=$_POST["email"];
      $dateofbirth=$_POST["dateofbirth"];
      $password=$_POST["password"];
      $repassword=$_POST["repassword"];
      $gender=$_POST["gender"];
      $address=$_POST["address"];
      $city=$_POST["city"];
      $designation=$_POST["designation"];
      $language=$_POST["language"];
      echo $password;
      $language = implode(",",$language);
      $temp = 0; 

      if($fname == '' || $username == '' || $email == '' || $dateofbirth == '' || $password == '' || $repassword == '' || $gender == '' || $city == ''
        || $designation == '' || $language == '') {
        $message = 'Kindly, Enter all the fields';
        echo "<script type='text/javascript'>alert('Kindly, Enter all the fields.');</script>";
      }
     else{
        if (!preg_match('/^[a-z\sA-Z]+$/', $fname)) {
          # code...
          echo "<script type='text/javascript'>alert('Name Should be character');</script>";
        }
        elseif (strlen($fname) > 25) {
          # code...
          echo "<script type='text/javascript'>alert('Name must be less then 25 character');</script>";
        }
        elseif (strlen($username) > 15) {
          # code...
          echo "<script type='text/javascript'>alert('Name must be less then 15 character');</script>";
        }
        
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
             
             echo "<script type='text/javascript'>alert('Invalid email format');</script>";

          }
          elseif (!preg_match('/^[a-z\sA-Z]+$/', $designation)) {
          # code...
          echo "<script type='text/javascript'>alert('Designaton Should be character');</script>";
        }
        else{
              if($password != $repassword){
               echo "<script type='text/javascript'>alert('Passwords didn\'t match.');</script>";
              }
              else{
                $sql = "SELECT * from faculty";
                $result=mysql_query($sql) or die(mysql_error());
                while($row = mysql_fetch_assoc($result)) {
                  if ($row['username'] == $username) {
                    # code...
                    echo "<script type='text/javascript'>alert('Kindly, Enter all the fields.');</script>";
                    $temp = 1;
                    break;
                  }
                  
                }
                if($temp == 0){
                  echo $sql="insert into faculty(fname,sname,username,email,dateofbirth,password,repassword,gender,address,city,cgpa,language,profile_pic)values('$fname','$sname','$username','$email','$dateofbirth','$password','$repassword','$gender','$address','$city','$cgpa','$language','$pic')";

                  $result=mysql_query($sql) or die(mysql_error());
                  header("location:loginnewfaculty.php");
                }

              }
        }
        
      }

      //echo $fname = $_REQUEST["fname"];
      //echo $sql="insert into register(fname,sname,username,email,dateofbirth,password,repassword,gender,address,city,cgpa,language,profile_pic)values('$fname','$sname','$username','$email','$dateofbirth','$password','$repassword','$gender','$address','$city','$cgpa','$language','$pic')";

      //$result=mysql_query($sql) or die(mysql_error());
      //$row=mysql_fetch_array($result);
      //$userid=$row["id"];
      //$total_record=mysql_num_rows($result);
      //$_SESSION["sid"]=$userid;
       //$sid=$_SESSION["sid"];
        //header("location:home.php?uid=$userid");
      //header("location:loginnew.php");




      /*if($data)
      {
        echo "data insert";
        }
        else{
          echo "data is not inserted";
          }*/
 }
 else{
  $fname = '';
  $username = '';
  $designation = '';
  $email = '';
  $password = '';
  $repassword = '';
  $dateofbirth = '';
 }
?>


<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Sign Up</title>
  <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  
      <link rel="stylesheet" href="css/style_reg.css">



</head>

<body>

<form action="faculty.php" method="post" enctype="multipart/form-data">

<!--  <a class="view__more" href="http://machycek.com" target="_blank">view more</a> -->
<div class="panel">
  <ul class="panel__menu" id="menu">
    <hr/>
    <li id="signIn"> <a href="#">Register as Teacher </a></li>
    <!--<li id="signUp"><a href="#">Sign up as Expert </a></li>-->
  </ul>
  <div class="panel__wrap">
    <div class="panel__box active" id="signInBox">
    <label>Full name
        <input type="text" name="fname" value="<?php echo $fname; ?>"/>
      </label>
      <label>Username
        <input type="text" name="username" value="<?php echo $username ?>"/>
      </label>
      <label>Email
        <input type="email" name="email" value="<?php echo $email ?>"/>
      </label>
      <label>Password
        <input type="password" name="password" value="<?php echo $password ?>"/>
      </label>
      <label>Re-type password
        <input type="password" name="repassword" value="<?php echo $repassword ?>"/>
      </label>
      <label>D.O.B
        <input type="date" name="dateofbirth" placeholder="YYYY-MM-DD" value="<?php echo $dateofbirth ?>"/>
      </label>
      <label>Gender</label>
      <label for="male" class="light">Male <input type="radio" id="male" value="male" name="gender"><br>
       <label for="female" class="light">female <input type="radio" id="female" value="female" name="gender">

      <label for="city">City</label>
        <select id="city" name="city" type="search">
           <option value="0">--SELECT--</option>
            <option value="indore">Indore</option>
            <option value="ujjain">Ujjain</option>
            <option value="dewas">Dewas</option>
            <option value="mumbai">Mumbai</option>
            <option value="banglore">Banglore</option>
            <option value="pune">Pune</option>
       </select><br>
      <label>DESIGNATION
        <input type="text" name="deisgnation"  value="<?php echo $designation ?>"/>
      </label>
      <label>Language</label>
       <label class="light" for="java">  JAVA <input type="checkbox" id="english" value="english" name="language[]"> <br>
         <label class="light" for="php"> PHP<input type="checkbox" id="hindi" value="hindi" name="language[]"> <br>
        <label class="light" for="python"> PYTHON <input type="checkbox" id="other" value="other" name="language[]">
                   <label class="light" for="others"> OTHERS<input type="checkbox" id="hindi" value="hindi" name="language[]"> <br>



  <label for="profile_pic">Profile Pic </label>
        <input type="file" name="profile_pic"  id="fileChooser" onchange="return ValidateFileUpload()" /> 
  <!--  <img src="img/noimg.jpg" id="blah"> -->

      <input type="submit" name="submit" value="Signup" class="submit"/>
    </div>
   </form>
   <!--
   <form action="expert_sub.php" method="post" enctype="multipart/form-data" name="fname2" onsubmit="returnvalid();">
    <div class="panel__box" id="signUpBox">
      <label>Full name
        <input type="text" name="fname" required/>
      </label>
      <label>Username
        <input type="text" name="username" />
      </label>
      <label>Email
        <input type="email" name="email" />
      </label>
      <label>Password
        <input type="password" name="password" />
      </label>
      <label>Re-type password
        <input type="password" name="repassword" />
      </label>
      <label>D.O.B
        <input type="date" name="dateofbirth" placeholder="YYYY-MM-DD" />
      </label>
      <label>Gender</label>
      <label for="male" class="light">Male <input type="radio" id="male" value="male" name="gender"><br>
       <label for="female" class="light">female <input type="radio" id="female" value="female" name="gender">

      <label for="city">City</label>
        <select id="city" name="city" type="search">
           <option value="0">--SELECT--</option>
            <option value="indore">Indore</option>
            <option value="ujjain">Ujjain</option>
            <option value="dewas">Dewas</option>
            <option value="mumbai">Mumbai</option>
            <option value="banglore">Banglore</option>
            <option value="pune">Pune</option>
       </select><br>
      <label>Designation
        <input type="text" name="designation" />
      </label>
      <label>Language</label>
       <label class="light" for="english">  English <input type="checkbox" id="english" value="english" name="language[]"> <br>
         <label class="light" for="hindi"> Hindi <input type="checkbox" id="hindi" value="hindi" name="language[]"> <br>
        <label class="light" for="other"> Other <input type="checkbox" id="other" value="other" name="language[]">


  <label for="profile_pic">Profile Pic </label>
        <input type="file" name="profile_pic"  id="fileChooser" onchange="return ValidateFileUpload()" /> 
  <!--  <img src="img/noimg.jpg" id="blah"> 

      <input type="submit" value="submit" class="submit"/>
    </div>
  </div>
</div>
  -->
    <script src="js/index.js"></script>
  <script type="text/javascript">
   <!--
      // Form validation code will come here.
      function validate()
      {
      
         if( document.myForm.Name.value == "" )
         {
            alert( "Please provide your name!" );
            document.myForm.Name.focus() ;
            return false;
         }
         
         if( document.myForm.EMail.value == "" )
         {
            alert( "Please provide your Email!" );
            document.myForm.EMail.focus() ;
            return false;
         }
         
         
         
         
         return( true );
      }
   //-->
</script>
<script type="text/javascript">
   <!--
      function validateEmail()
      {
         var emailID = document.myForm.EMail.value;
         atpos = emailID.indexOf("@");
         dotpos = emailID.lastIndexOf(".");
         
         if (atpos < 1 || ( dotpos - atpos < 2 )) 
         {
            alert("Please enter correct email ID")
            document.myForm.EMail.focus() ;
            return false;
         }
         return( true );
      }
   //-->
</script>

</body>
</html>
