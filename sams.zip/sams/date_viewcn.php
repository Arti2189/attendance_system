<?php 
include 'inc/header.php';
include 'lib/Studentcn.php';
 ?>

    


<!--<html>
<head>
<meta charset="utf-8">
<title> student attendance php</title><


<link rel= "stylesheet" href="inc/bootstrap.min.css" media="screen" title= "no title"/>
<script type="text/javascript" src="inc/jquery.min.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class= "well text-center">
			<h2> Attendance</h2></div>-->

               <div class="panel panel-default"></div>
               <div class="panel-heading">
               	<h2>
               		<a class="btn btn-success" href="addcn.php">Add Student</a>
               		<a class="btn btn-info pull-right" href="indexcn.php">Take Attendance</a>
               	</h2>
               </div>
                <div class="panel-body">
                	     <form action="" method="post">
                       	<table class="table table-striped">
                       		<tr>
                       			<th width="30%"> Serial No.</th>
                       			<th width="50%"> Attendance Date</th>
                       			<th width="20%"> Action</th>
                       			
                       		</tr>


                       		<?php
                             $stu = new Student();
                       		$get_date = $stu->getDateList();
                       		if ($get_date){
                       			$i = 0;
                       			while ($value = $get_date->fetch_assoc()) {
                       				$i++;
                       			
                       		

                       		?>
                                 <tr>
    <td><?php echo $i; ?></td>
	<td><?php echo $value['att_time']; ?></td>
  
  <td>
    <a class= "btn btn-primary" href ="student_viewcn.php?dt=<?php echo $value['att_time']; ?>"> View</a>
  </td>
</tr>
<?php } }  ?>


  
                       	</table>
                   </form>
                </div>



			<div class="well">
			</div></div>

</body>
</html>