<?php 
   session_start();
   if(!isset($_SESSION['sid'])){
      header("location:loginnew.php");
   }
?>

<html>
<head>
<meta charset="utf-8">
<title> student attendance php</title>


<link rel= "stylesheet" href="inc/bootstrap.min.css" media="screen" title= "no title"/>
<script type="text/javascript" src="inc/jquery.min.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>
</head>
<body>
	<body>



    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        
                    </a>
                </li>
                <li>
                    <a href="homefaculty.php">Dashboard</a>
                </li>
                <li>
                    <a href="index.php">Attendance</a></li>
</li>
                <li>
                    <a href="viewattendance.php">Overall Attendance</a>
                </li>
    
    <li><a href="#">About Us</a></li>
    <li><a href="logout.php">logout</a></li>
    
                
                   
                
            </ul>
        </div>
           <br><br><br><br>  <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Menu</a>
                            
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

 
	<div class="container">
		<div class= "well text-center">
			<h2> Attendance</h2></div>
