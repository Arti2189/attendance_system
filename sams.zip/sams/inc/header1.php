<?php 
   session_start();
   if(!isset($_SESSION['sid'])){
      header("location:loginnew.php");
   }
?>



<?php include "lib/config.php"; ?>
<?php include "lib/Database.php"; ?>
<?php include "helpers/Format.php"; ?>
<?php error_reporting(0); ?>


<?php 
	$db = new Database();
	$fm = new Format();
	?>
<!DOCTYPE html>
<html>
<head>
	<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta charset="UTF-8">
<title>
PROTEGE
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	

<meta name="language" content="English">
	<meta name="description" content="It is a website about education">
	<meta name="keywords" content="blog,cms blog">
	<meta name="author" content="Delowar">
	<link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.css">	
	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>

<script type="text/javascript">
$(window).load(function() {
	$('#slider').nivoSlider({
		effect:'random',
		slices:10,
		animSpeed:500,
		pauseTime:5000,
		startSlide:0, //Set starting Slide (0 index)
		directionNav:false,
		directionNavHide:false, //Only show on hover
		controlNav:false, //1,2,3...
		controlNavThumbs:false, //Use thumbnails for Control Nav
		pauseOnHover:true, //Stop animation while hovering
		manualAdvance:false, //Force manual transitions
		captionOpacity:0.8, //Universal caption opacity
		beforeChange: function(){},
		afterChange: function(){},
		slideshowEnd: function(){} //Triggers after all slides have been shown
	});
});
</script>
  
<!-- Bootstrap Core CSS -->
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 
    <!-- Custom CSS -->
    <link href="inc/simple-sidebar.css" rel="stylesheet">

 
 </head>

<body>
	 <div id="wrapper">

	        <!-- Sidebar 
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        
                    </a>
                </li>
                <li>
                    <a href="addpost.php">Write Blogs</a>
                </li>
                <li>
                    <a href="#">View My Blogs</a>
                </li>
                <li>
                    <a href="#">ViewAttendance</a>
                </li>
               
                <li>
                    <a href="#">Send Messages</a>
                </li>
                

                <li>
                    <a href="#">About</a>
                </li>
                
                
            </ul>
        </div>
           <br><br><br> <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Menu</a>
                            
        <!-- /#page-content-wrapper -->

    </div>
     <!-- jQuery
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>
     /#wrapper -->

   <br><br><br>

 
 
<div class="nav">
		<div class='logo'></div>
		<ul class="menu">
		<li class="btMenu">
		<a href="javascript:void(0)">MENU</a></li>
		<li class="menuItem"><a href="home1.php">Home</a></li>
		<li class="menuItem"><a href="index2.php">Blogs</a></li>
				<li class="menuItem"><a href="addpost.php">Write Blogs</a></li>

		<li class="menuItem"><a href="index2news.php">News</a></li>
		<li class="menuItem"><a href="viewattendance.php">Attendance</a></li>
		<li class="menuItem"><a href="logout.php">Logout</a></li>

		
		
		</ul>
		</div>
		
		
		<body>
	<div class="headersection templete clear">
		<a href="#">
			<div class="logo">
				<img src="images/logo.png" alt="Logo"/>
				<h2>Website Title</h2>
				<p>Our website description</p>
			</div>
		</a>
		<!--<form action="index2.php" method="POST">
						<input type="submit" name="submit"  value="back"/>
-->
		<div class="social clear">
			
			
		
			
			</form>
			<div class="searchbtn clear">
			<form action="search.php" method="get">
				<input type="text" name="search" placeholder="Search keyword..."/>
				<input type="submit" name="submit" value="Search"/>

			</form>
						

			</div>

		</div>
	</div>
	<center><img src="images/slideshow/aa.jpg" ></center>

	


