<div class="sidebar clear">
			<div class="samesidebar clear">
				<h3>Categories</h3>
					<ul>
						<?php 
				$query="select * from tb_category";
				$category = $db->select($query);
                if ($category) {
                	while ($result = $category->fetch_assoc()) {
                		

				?>
						<li><a href="posts.php?category=<?php echo $result['id']; ?>"><?php echo $result['name']; ?></a></li>
						<?php } } else { ?>
						<li>No Category </li>
						<?php } ?>
						</ul>
			</div>
			
			<div class="samesidebar clear">
				<h3>Latest articles</h3>
				<?php 
				$query="select * from tb_post ORDER BY id DESC limit 5";
				$category = $db->select($query);
                if ($category) {
                	while ($result = $category->fetch_assoc()) {
                		

	                 ?>
					<div class="popular clear">
						<h3><a href="post.php?id=<?php echo $result['id']; ?>" ><?php echo $result['title']; ?></a></h3>			
						<a href="post.php?id=<?php echo $result['id']; ?>"><img src="admin/upload/<?php echo $result['image']; ?>" alt="post image"/></a>
				 <?php echo $fm->textShorten($result['body'], 120); ?>
					</div>
					<?php } } else {header("Location:404.php"); } ?>
	
			</div>
			
		</div>