<div class="slidersection templete clear">
        <div id="slider">
            <a href="#"><img src="images/slideshow/bb.jpg" alt="nature 1" title="" /></a>
        </div>

</div>	