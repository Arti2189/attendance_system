function formValidation()  
{  
var uid = document.registration.username;  
var password = document.registration.password;  
var uname = document.registration.username;  
var address = document.registration.address;  
var city = document.registration.city;  
var cgpa = document.registration.cgpa;  
var email = document.registration.email;  
var male = document.registration.male;  
var female = document.registration.female; if(username_validation(uid,5,12))  
{  
if(password_validation(password,7,12))  
{  
if(allLetter(uname))  
{  
if(alphanumeric(address))  
{   
if(countryselect(city))  
{  
if(allnumeric(cgpa))  
{  
if(ValidateEmail(email))  
{  
if(validsex(male,female))  
{  
}  
}   
}  
}   
}  
}  
}  
}  
return false;  
}  
function username_validation(uid,mx,my)  
{  
var uid_len = uid.value.length;  
if (uid_len == 0 || uid_len >= my || uid_len < mx)  
{  
alert("User Id should not be empty / length be between "+mx+" to "+my);  
uid.focus();  
return false;  
}  
return true;  
}  
function password_validation(password,mx,my)  
{  
var password_len = password.value.length;  
if (password_len == 0 ||password_len >= my || password_len < mx)  
{  
alert("Password should not be empty / length be between "+mx+" to "+my);  
password.focus();  
return false;  
}  
return true;  
}

function allLetter(uname)  
{   
var letters = /^[A-Za-z]+$/;  
if(uname.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('Username must have alphabet characters only');  
uname.focus();  
return false;  
}  
}  
function alphanumeric(address)  
{   
var letters = /^[0-9a-zA-Z]+$/;  
if(address.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('User address must have alphanumeric characters only');  
address.focus();  
return false;  
}  
}  

function countryselect(city)  
{  
if(city.value == "Default")  
{  
alert('Select your country from the list');  
city.focus();  
return false;  
}  
else  
{  
return true;  
}  
}  

function ValidateEmail(email)  
{  
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
if(email.value.match(mailformat))  
{  
return true;  
}  
else  
{  
alert("You have entered an invalid email address!");  
email.focus();  
return false;  
}  
}  
unction validsex(male,female)  
{  
x=0;  
  
if(male.checked)   
{  
x++;  
} if(female.checked)  
{  
x++;   
}  
if(x==0)  
{  
alert('Select Male/Female');  
male.focus();  
return false;  
}  
else  
{  
alert('Form Successfully Submitted');  
window.location.reload()  
return true;}  
}  


