<?php
 include 'inc/header.php'; 
include 'lib/Student.php';
?>

<?php
   $stu = new Student();
   
   $name = $_POST['name'];
   $roll = $_POST['roll'];
   if($name !=null)
{

  $insertdata = $stu->insertStudent($name, $roll);
}
  ?>

   
<?php
   if (isset($insertdata)) {
     echo $insertdata;
   }
   ?>
<!--<html>
<head>
<meta charset="utf-8">
<title> student attendance php</title><


<link rel= "stylesheet" href="inc/bootstrap.min.css" media="screen" title= "no title"/>
<script type="text/javascript" src="inc/jquery.min.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class= "well text-center">
			<h2> Attendance</h2></div>-->

               <div class="panel panel-default"></div>
               <div class="panel-heading">
               	<h2>
               		<a class="btn btn-success" href="add.php">Add Student</a>
               		<a class="btn btn-info pull-right" href="index.php">Back</a>
               	</h2>
               </div>
                <div class="panel-body">
                      <form action="./add.php" method="post">
                        <div class= "form-group">
                          <label for="name">Student Name</label>
                          <input type="text" class="form-control" name="name" id="name">
                        </div>
                        <div class= "form-group">
                          <label for="roll">Enrollment</label>
                          <input type="text" class="form-control" name="roll" id="roll">
                        </div>
                        <div class= "form-group">
                          
                          <input type="submit" class ="btn btn-primary" name="submit" value="Add Student">
                       	</div>
                   </form>
                </div>



		</div>

</body>
</html>