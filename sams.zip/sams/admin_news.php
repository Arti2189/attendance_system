<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Tata Consultancy Services Ltd.</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link href="css/style_company.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php include '../header.php';?>
<form action="admin_news_sub.php" method="post" enctype="multipart/form-data" name="fname2" onsubmit="returnvalid();">

<div id="gutter"></div>
<div id="col1">
<p>mxklsdmcfrkofpocv,l.fdkfgiorkorlf;lcbgtdfydgeuidfiedcokvcfiopkv ofk 09fv  mxklsdmcfrkofpocv,l.fdkfgiorkorlf;lcbgtdf </p>
  <div id="container">
    <h2> <center><span style="font-weight:bold; color:#333;">Update News</span> </center></h2>

	<div class="page_content">
    	Page Content Here....
    </div>
 <div class="comment_input">
        	<input type="text" name="name" placeholder="Name..."/></br></br>
            <textarea name="news" placeholder="Leave News Here..." style="width:350px; height:250px;">
                   
           </textarea><br>
             <label for="picture">Upload file </label>
        <input type="file" name="picture"  id="fileChooser" onchange="return ValidateFileUpload()" style="padding:10px; margin:5px;"/> 
  <!--  <img src="img/noimg.jpg" id="blah"> -->

           </br>

            <label for="profile_pic"> Arbitrary Pic</label>
        <input type="file" name="profile_pic"  id="fileChooser" onchange="return ValidateFileUpload()" style="padding:5px; margin:5px;"/> 
  <!--  <img src="img/noimg.jpg" id="blah"> -->

     </br>
          <input type="submit" value="POST" class="submit"/>

        </form>

    </div>
  </div>
 

</body>
</html>
