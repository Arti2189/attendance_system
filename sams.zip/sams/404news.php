<?php include "inc/headernews.php"; ?>


<?php
error_reporting(0);
?> 
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
				<div class="notfound">
    				<p><span></span> Not Available</p>
    			</div>
	        </div>
		</div>
		
	<?php include "inc/sidebarnews.php"; ?>
		<?php include "inc/footernews.php";
	?>

	