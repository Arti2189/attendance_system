<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta charset="UTF-8">
<title>
PROTEGE
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel= "stylesheet" href="inc/bootstrap.min.css" media="screen" title= "no title"/>
<script type="text/javascript" src="inc/jquery.min.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    <!-- Bootstrap Core CSS -->
    <link href="inc/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="inc/simple-sidebar.css" rel="stylesheet">

<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->

 
 </head>

<body>



    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        
                    </a>
                </li>
                <li>
                    <a href="#">Dashboard</a>
                </li>
                <li>
                    <a href="#">Attendance</a>
                </li>
               
                <li>
                    <a href="#">Overall Attendance</a>
                </li>
                <li>
                    <a href="#">News Feed</a>
                </li>

                <li>
                    <a href="#">About</a>
                </li>
                
                
            </ul>
        </div>
           <br><br><br><br>  <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Menu</a>
                            
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

 
<div class="nav">
        <div class='logo'></div>
        <ul class="menu">
        <li class="btMenu">
        <a href="javascript:void(0)">MENU</a></li>
        <li class="menuItem"><a href="index.html">Home</a></li>
        <li class="menuItem"><a href="#">About Us</a></li>
        <li class="menuItem"><a href="#">Mission</a></li>
        <li class="menuItem"><a href="#">Features</a></li>
        <li class="menuItem"><a href="#">Why Us</a></li>
        <li class="menuItem"><a href="http://www.scriptcafe.in">Events</a></li>
        
        
        </ul>
        </div>
          
          </div>

          
           <br>
          

           <div class="container">

           <ul class="nav nav-pills" role="tablist">
  <li role="presentation" class="active"><a href="#">Compose</a></li>
  <li role="presentation"><a href="#">Inbox</a></li>
  <li role="presentation"><a href="#">Outbox <span class="badge">3</span></a></li>
</ul>
</div>
<div class="container">

  
</div>