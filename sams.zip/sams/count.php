<?php 
mysql_connect("localhost","root","");
mysql_select_db("db_sams"); 

$totalenroll[];
$enrolls="select enroll from tb_attendance";

foreach($enroll as $en)
{
$n="select count(attend) from tb_attendance where enroll=en and attend='p'";

if $en not in $totalenroll
{
$totalenroll.push($en=>$n);
}
}
$count=0;
foreach($total $enroll as $_get)
{
$count=$count+$_get.[$en];
}
echo $count;
?>