﻿<?php include 'inc/header2.php';
   session_start();
   if(!isset($_SESSION['sid'])){
      header("location:loginnew.php");
   }
?>

        
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>

                <?php 
                  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                       $title = $_POST['title'];
                       $cat = $_POST['cat'];
                       $body = $_POST['body'];
                       $tags = $_POST['tags'];
                       $author = $_POST['author'];

                       if($title == '' || $cat == '' || $body == '' || $tags == '' || $author == '') {
                        $message = 'Kindly, Enter all the fields';
                        echo "<script type='text/javascript'>alert('Kindly, Enter all the fields.');</script>";
                      }
                     else{
                        if (!preg_match('/^[a-z\sA-Z0-9]+$/', $title)) {
                          # code...
                          echo "<script type='text/javascript'>alert('Title should be Varchar');</script>";
                        }
                        elseif (strlen($author) > 25) {
                          # code...
                          echo "<script type='text/javascript'>alert('Author name must be less then 25 character');</script>";
                        }
                        elseif (!preg_match('/^[a-z\sA-Z]+$/', $author)) {
                          # code...
                          echo "<script type='text/javascript'>alert('Author name should be character');</script>";
                        }
                        elseif (!preg_match('/^[a-z\sA-Z0-9]+$/', $tags)) {
                          # code...
                          echo "<script type='text/javascript'>alert('Tags can not contain special character');</script>";
                        }
                        else{
                              $permited  = array('jpg', 'jpeg', 'png', 'gif');
                              $file_name = $_FILES['image']['name'];
                              $file_size = $_FILES['image']['size'];
                              $file_temp = $_FILES['image']['tmp_name'];

                              $div = explode('.', $file_name);
                              $file_ext = strtolower(end($div));
                              $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                              $uploaded_image = "upload/".$unique_image;

                              $query = "INSERT INTO tb_post(cat, title, body, image, author, tags)  VALUES('$cat', '$title',  '$body', '$uploaded_image', '$author', '$tags')";
                
                              $inserted_rows = $db->insert($query);
                              
                              if ($inserted_rows) {
                               echo "<span class='success'>Post Inserted Successfully.
                               </span>";
                              }else {
                               echo "<span class='error'>Post Not Inserted !</span>";
                              }
                            }
                        
                      }

                       // $title = mysql_real_escape_string($db->link, $_Post[$title]);    
                       //$cat = mysql_real_escape_string($db->link,  $_Post[$cat]);    
                      // $body = mysql_real_escape_string($db->link, $_Post[$body]);    
                      // $tags = mysql_real_escape_string($db->link, $_Post[$tags]);    
                      // $author = mysql_real_escape_string($db->link, $_Post[$author]);    

                       

                      
   /**if ($title == "" || $cat == "" || $body == "" || $tags == "" || $author == "" || $file_name == "" ) {
       echo "<span class='error'> Field must not be empty !</span>";

                     }if ($file_size > 1048567) {
     
     echo "<span class='error'>Must be less then 1MB:-</span>";
    


 }elseif (in_array($file_ext, $permited) === false) {
     
     echo "<span class='error'>You can upload only:-"
    
     .implode(', ', $permited)."</span>";
    
    } else{
    
    move_uploaded_file($file_temp, $uploaded_image);*/
    
                
           }
           else{
                       $title = '';
                       $cat = '';
                       $body = '';
                       $tags = '';
                       $author = '';
           }
                  
        ?>
                <div class="block">               
                 <form action="addpost.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name = "title" placeholder="Enter Post Title..." class="medium" value="<?php echo $title; ?>"/>
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat" value="<?php echo $cat; ?>">
                                    <option>Select Category</option>
                                    <?php 
                                       $query = "select * from tb_category";
                                       $category = $db->select($query);
                                       if ($category) {
                        
                                       while ($result = $category->fetch_assoc()) {
                                       
                                    ?>
                                    <option value="<?php echo $result['id']; ?>"><?php echo $result['name']; ?></option>
                                    <?php } } ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name = "image"/>
                            </td>
                        </tr>
                         
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce"  name = "body" value="<?php echo $body; ?>"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" name = "tags" placeholder="Enter tags..." class="medium" value="<?php echo $tags; ?>"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" name = "author" placeholder="Enter author name..." class="medium" value="<?php echo $author; ?>"/>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Post" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>

        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
            <script type="text/tiny-mce/tiny-mce.js" type="text/javascript"></script>

        <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
        </script>
                <?php include 'inc/footer2.php'; ?>

