<?php

error_reporting(0);
mysql_connect("localhost","root","");
mysql_select_db("phpclass"); 

$name=$_POST["name"];
$news=$_POST["news"];
$pic=$_FILES["picture"]["name"];
move_uploaded_file($_FILES["picture"]["tmp_name"],"../photo/$pic");
$datetime=date("d/m/y h:i:s"); //create date time
$profile_picture=$_FILES["profile_pic"]["name"];
move_uploaded_file($_FILES["profile_pic"]["tmp_name"],"../photo/$profile_picture");

echo $sql="INSERT INTO news(name,pic,profile_pic,news,datetime)VALUES('$name','$pic','$profile_picture','$news','$datetime')";
$result=mysql_query($sql) or die(mysql_error());
$row=mysql_fetch_array($result);
$total_record=mysql_num_rows($result);


 	header("location:admin_news.php");

/*if($total_record>0)
{
	//header("location:home.php?uid=$userid");
	header("location:csc_faq.php");
}
else
{
	header("location:home.php");
}*/
?>